"""Backends for the demo.

We create two *simulated* backends with different noise fingerprints to mimic
"backend-to-backend variability" that  would adapt to.
"""

from __future__ import annotations

from dataclasses import dataclass

from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error, ReadoutError


@dataclass
class DemoBackend:
    name: str
    simulator: AerSimulator


def _make_noise_model(
    p1: float,
    p2: float,
    readout_p01: float,
    readout_p10: float,
) -> NoiseModel:
    nm = NoiseModel()

    # Gate errors
    e1 = depolarizing_error(p1, 1)
    e2 = depolarizing_error(p2, 2)
    nm.add_all_qubit_quantum_error(e1, ["x", "y", "z", "rx", "ry", "rz", "h"])
    nm.add_all_qubit_quantum_error(e2, ["cx", "cz"])

    # Readout error (same for all qubits)
    ro = ReadoutError([[1 - readout_p01, readout_p01], [readout_p10, 1 - readout_p10]])
    nm.add_all_qubit_readout_error(ro)

    return nm


def make_demo_backends() -> list[DemoBackend]:
    """Two demo backends: 'backend_A' is cleaner; 'backend_B' is noisier but different."""

    noise_A = _make_noise_model(p1=0.002, p2=0.02, readout_p01=0.02, readout_p10=0.03)
    noise_B = _make_noise_model(p1=0.004, p2=0.04, readout_p01=0.05, readout_p10=0.08)

    sim_A = AerSimulator(noise_model=noise_A)
    sim_B = AerSimulator(noise_model=noise_B)

    return [
        DemoBackend(name="backend_A", simulator=sim_A),
        DemoBackend(name="backend_B", simulator=sim_B),
    ]
