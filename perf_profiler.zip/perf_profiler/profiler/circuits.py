"""Circuit families for the demo.

We include:
- Readout calibration circuits (|0>,|1>)
- Depth sweep circuits (repeat entangling structure)
- Algorithm suite circuits (QAOA-like, random, GHZ, GDJ toy)

These are small, fast to run, and easy to explain.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from qiskit import QuantumCircuit


@dataclass
class LabeledCircuit:
    name: str
    circuit: QuantumCircuit
    family: str


def make_readout_calibration_circuits(n: int = 1) -> list[LabeledCircuit]:
    circs: list[LabeledCircuit] = []

    # |0> measurement
    qc0 = QuantumCircuit(n, n)
    qc0.measure(range(n), range(n))
    circs.append(LabeledCircuit(name=f"readout_cal_0_{n}q", circuit=qc0, family="readout_cal"))

    # |1> measurement
    qc1 = QuantumCircuit(n, n)
    for q in range(n):
        qc1.x(q)
    qc1.measure(range(n), range(n))
    circs.append(LabeledCircuit(name=f"readout_cal_1_{n}q", circuit=qc1, family="readout_cal"))

    return circs


def make_depth_sweep_circuits(n: int = 4, depths: list[int] | None = None) -> list[LabeledCircuit]:
    depths = depths or [1, 2, 3, 4, 5]
    out: list[LabeledCircuit] = []

    for d in depths:
        qc = QuantumCircuit(n, n)
        qc.h(0)
        # Repeat an entangling motif to increase depth.
        for _ in range(d):
            for i in range(n - 1):
                qc.cx(i, i + 1)
            for i in range(n):
                qc.rz(0.2, i)
        qc.measure(range(n), range(n))
        out.append(LabeledCircuit(name=f"depth_sweep_{n}q_d{d}", circuit=qc, family="depth_sweep"))

    return out


def make_ghz(n: int) -> QuantumCircuit:
    qc = QuantumCircuit(n, n)
    qc.h(0)
    for i in range(n - 1):
        qc.cx(i, i + 1)
    qc.measure(range(n), range(n))
    return qc


def make_random(n: int, depth: int = 5, seed: int = 0) -> QuantumCircuit:
    rng = random.Random(seed)
    qc = QuantumCircuit(n, n)

    for _ in range(depth):
        for q in range(n):
            qc.ry(rng.random(), q)
        for _ in range(n):
            q0, q1 = rng.sample(range(n), 2)
            qc.cx(q0, q1)

    qc.measure(range(n), range(n))
    return qc


def make_qaoa_like(n: int, p: int = 2) -> QuantumCircuit:
    qc = QuantumCircuit(n, n)
    qc.h(range(n))

    for _ in range(p):
        # ring entanglers
        for i in range(n):
            j = (i + 1) % n
            qc.cx(i, j)
            qc.rz(0.5, j)
            qc.cx(i, j)
        qc.rx(0.7, range(n))

    qc.measure(range(n), range(n))
    return qc


def make_gdj_toy(n: int = 3, balanced: bool = True) -> QuantumCircuit:
    """Small toy GDJ-like circuit (oracle-style structure) for demo purposes.

    We use n input qubits + 1 ancilla. The oracle is represented by CX pattern.
    This is NOT a full GDJ implementation; it's a small "oracle-heavy" pattern.
    """

    qc = QuantumCircuit(n + 1, n + 1)
    anc = n

    # prepare ancilla
    qc.x(anc)
    qc.h(anc)

    # Hadamards on inputs
    qc.h(range(n))

    # toy oracle
    if balanced:
        # couple a couple of inputs to ancilla
        qc.cx(0, anc)
        qc.cx(1, anc)
    else:
        # constant oracle does nothing
        pass

    # interference
    qc.h(range(n))

    qc.measure(range(n + 1), range(n + 1))
    return qc


def make_algorithm_suite(max_qubits: int = 6) -> list[LabeledCircuit]:
    n = max(3, min(max_qubits, 6))
    suite: list[LabeledCircuit] = []

    suite.append(LabeledCircuit(name=f"ghz_{n}", circuit=make_ghz(n), family="ghz"))
    suite.append(LabeledCircuit(name=f"random_{n}", circuit=make_random(n, depth=5, seed=1), family="random"))
    suite.append(LabeledCircuit(name=f"qaoa_like_{n}", circuit=make_qaoa_like(n, p=2), family="qaoa_like"))
    suite.append(LabeledCircuit(name="gdj_toy_3_balanced", circuit=make_gdj_toy(3, balanced=True), family="gdj_oracle"))

    return suite
