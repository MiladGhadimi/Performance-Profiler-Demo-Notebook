"""Metrics and signature extraction."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

import numpy as np
import pandas as pd

from qiskit import transpile

from .backends import DemoBackend
from .circuits import LabeledCircuit


def _run_counts(backend: DemoBackend, qc, shots: int, opt_level: int = 1) -> dict[str, int]:
    tqc = transpile(qc, backend.simulator, optimization_level=opt_level)
    job = backend.simulator.run(tqc, shots=shots)
    res = job.result()
    counts = res.get_counts(0)
    return counts


def compute_readout_confusion(
    backend: DemoBackend,
    cal_circuits: list[LabeledCircuit],
    shots: int = 2000,
) -> np.ndarray:
    """Return 2x2 confusion matrix for 1-qubit readout.

    Rows: prepared state (0,1)
    Cols: measured bit (0,1)
    """

    assert len(cal_circuits) == 2
    c0 = _run_counts(backend, cal_circuits[0].circuit, shots=shots, opt_level=1)
    c1 = _run_counts(backend, cal_circuits[1].circuit, shots=shots, opt_level=1)

    p00 = c0.get("0", 0) / shots
    p01 = c0.get("1", 0) / shots
    p10 = c1.get("0", 0) / shots
    p11 = c1.get("1", 0) / shots

    M = np.array([[p00, p01], [p10, p11]], dtype=float)
    return M


def compute_depth_signature(
    backend: DemoBackend,
    depth_circuits: list[LabeledCircuit],
    shots: int = 2000,
) -> dict[str, float]:
    """Compute a simple 'depth decay' signature.

    We use success probability of the most-likely bitstring as a proxy and fit:
      log(p_success) ~ a - k * depth

    Returns decay_rate=k and r2.
    """

    depths = []
    ps = []

    for lc in depth_circuits:
        # parse depth from name: ..._d{d}
        d = int(lc.name.split("_d")[-1])
        counts = _run_counts(backend, lc.circuit, shots=shots, opt_level=1)
        p_success = max(counts.values()) / shots
        depths.append(d)
        ps.append(max(1e-9, p_success))

    x = np.array(depths, dtype=float)
    y = np.log(np.array(ps, dtype=float))

    # Fit y = b + m x, where m ~ -k
    m, b = np.polyfit(x, y, 1)
    yhat = m * x + b
    ss_res = np.sum((y - yhat) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2) + 1e-12
    r2 = 1.0 - ss_res / ss_tot

    decay_rate = float(max(0.0, -m))

    return {"decay_rate": decay_rate, "r2": float(r2)}


def _success_prob_from_counts(counts: dict[str, int], shots: int) -> float:
    return max(counts.values()) / shots


def compute_suite_metrics(
    backends: list[DemoBackend],
    suite: list[LabeledCircuit],
    shots: int,
    opt_level: int,
    mitigator=None,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []

    for b in backends:
        for lc in suite:
            counts = _run_counts(b, lc.circuit, shots=shots, opt_level=opt_level)
            if mitigator is not None:
                probs = mitigator.correct_counts(counts, shots=shots)
                p = float(np.max(list(probs.values())))
            else:
                p = _success_prob_from_counts(counts, shots)

            n2q = lc.circuit.count_ops().get("cx", 0) + lc.circuit.count_ops().get("cz", 0)
            depth = lc.circuit.depth()

            rows.append(
                {
                    "backend": b.name,
                    "circuit": lc.name,
                    "family": lc.family,
                    "opt_level": opt_level,
                    "shots": shots,
                    "depth": int(depth),
                    "n2q": int(n2q),
                    "p_success": float(p),
                    "mitigation": bool(mitigator is not None),
                }
            )

    return pd.DataFrame(rows)
