"""Profiler package (demo)."""
