"""Very simple recommendation policy.

 idea: use quick diagnostics to choose a backend and knobs.
"""

from __future__ import annotations

import pandas as pd


def recommend_plan(signature_df: pd.DataFrame) -> dict:
    """Choose backend + knobs from signature.

    Strategy (simple, explainable):
    - prefer lower depth_decay
    - penalize higher readout error
    - enable readout mitigation if readout error is above a threshold
    - use higher optimization level if depth_decay is high
    """

    df = signature_df.copy()
    df["readout_err"] = df["readout_p01"] + df["readout_p10"]

    # score: lower is better
    df["score"] = 3.0 * df["depth_decay"] + 1.0 * df["readout_err"]

    best = df.sort_values("score").iloc[0]

    readout_mitigation = bool(best["readout_err"] > 0.08)
    opt_level = 3 if float(best["depth_decay"]) > 0.08 else 2

    return {
        "backend": str(best["backend"]),
        "opt_level": int(opt_level),
        "readout_mitigation": bool(readout_mitigation),
        "notes": "Rule-based demo policy; can be replaced by Bayesian/ML tuner.",
    }
