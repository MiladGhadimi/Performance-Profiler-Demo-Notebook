"""Plotting + report writing."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def plot_signature_overview(sig_df: pd.DataFrame, out_path: Path) -> None:
    """Simple bar overview: readout error + depth decay per backend."""

    df = sig_df.copy()
    df["readout_err"] = df["readout_p01"] + df["readout_p10"]

    x = np.arange(len(df))

    plt.figure()
    plt.bar(x - 0.15, df["readout_err"].values, width=0.3, label="readout error (p01+p10)")
    plt.bar(x + 0.15, df["depth_decay"].values, width=0.3, label="depth decay rate")
    plt.xticks(x, df["backend"].tolist())
    plt.ylabel("signature")
    plt.title("Error signature overview")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def plot_baseline_vs_optimized(
    baseline_df: pd.DataFrame,
    optimized_df: pd.DataFrame,
    out_path: Path,
) -> None:
    """Compare p_success baseline vs optimized for each circuit."""

    # baseline: choose best baseline backend per circuit (max)
    base = baseline_df.groupby("circuit")["p_success"].max().reset_index()
    opt = optimized_df.groupby("circuit")["p_success"].max().reset_index()

    merged = base.merge(opt, on="circuit", suffixes=("_baseline", "_optimized"))

    x = np.arange(len(merged))
    plt.figure(figsize=(8, 4.5))
    plt.bar(x - 0.2, merged["p_success_baseline"].values, width=0.4, label="baseline")
    plt.bar(x + 0.2, merged["p_success_optimized"].values, width=0.4, label="optimized")
    plt.xticks(x, merged["circuit"].tolist(), rotation=20, ha="right")
    plt.ylim(0.0, 1.0)
    plt.ylabel("success proxy")
    plt.title("Baseline vs optimized execution")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def write_markdown_summary(
    out_path: Path,
    signature: pd.DataFrame,
    plan: dict,
    baseline: pd.DataFrame,
    optimized: pd.DataFrame,
) -> None:
    base_best = baseline.groupby("circuit")["p_success"].max()
    opt_best = optimized.groupby("circuit")["p_success"].max()

    lines = []
    lines.append("#  Performance Profiler — Demo Report\n")

    lines.append("## 1) Error signature (diagnostics)\n")
    lines.append(signature.to_markdown(index=False))
    lines.append("\n")

    lines.append("## 2) Recommended plan\n")
    lines.append(f"- **Chosen backend:** `{plan['backend']}`\n")
    lines.append(f"- **Transpiler optimization level:** `{plan['opt_level']}`\n")
    lines.append(f"- **Readout mitigation:** `{plan['readout_mitigation']}`\n")
    lines.append(f"- Notes: {plan.get('notes','')}\n")

    lines.append("## 3) Algorithm suite results (success proxy)\n")
    lines.append("Baseline is the best default run across available backends. Optimized is the recommended run.\n")

    rows = []
    for circ in sorted(set(base_best.index) | set(opt_best.index)):
        b = float(base_best.get(circ, np.nan))
        o = float(opt_best.get(circ, np.nan))
        imp = 100.0 * (o - b) / b if (b > 0 and np.isfinite(b) and np.isfinite(o)) else 0.0
        rows.append({"circuit": circ, "baseline": b, "optimized": o, "improve_%": imp})

    df = pd.DataFrame(rows)
    lines.append(df.to_markdown(index=False))
    lines.append("\n")

    out_path.write_text("\n".join(lines), encoding="utf-8")
