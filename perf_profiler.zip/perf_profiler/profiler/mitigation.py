"""Readout mitigation via confusion-matrix inversion (tensor-product assumption)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np


def _kron_n(mat: np.ndarray, n: int) -> np.ndarray:
    out = np.array([[1.0]])
    for _ in range(n):
        out = np.kron(out, mat)
    return out


@dataclass
class ReadoutMitigator:
    """Mitigate readout errors by inverting an estimated assignment matrix.

    This assumes independent readout errors across qubits.
    For n<=6 this is still fast and easy to demo.
    """

    A_inv: np.ndarray
    num_qubits: int

    @staticmethod
    def from_1q_confusion(M: np.ndarray, num_qubits: int) -> "ReadoutMitigator":
        # M is 2x2 where rows=prepared, cols=measured.
        # For mitigation we want measured_probs -> corrected_probs.
        # Under independent errors, assignment matrix for n qubits is kron(M, ..., M).
        A = _kron_n(M, num_qubits)
        # pseudo-inverse for stability
        A_inv = np.linalg.pinv(A)
        return ReadoutMitigator(A_inv=A_inv, num_qubits=num_qubits)

    def correct_counts(self, counts: Dict[str, int], shots: int) -> Dict[str, float]:
        dim = 2 ** self.num_qubits
        p_meas = np.zeros(dim, dtype=float)

        # Qiskit bitstring order: little-endian in some contexts; for demo we treat strings as-is.
        # We'll map bitstrings to integer with standard binary interpretation.
        for bitstr, c in counts.items():
            idx = int(bitstr, 2)
            p_meas[idx] += c / shots

        p_corr = self.A_inv @ p_meas
        # clip and renormalize
        p_corr = np.clip(p_corr, 0.0, 1.0)
        s = float(np.sum(p_corr))
        if s > 0:
            p_corr /= s

        out: Dict[str, float] = {}
        for idx, p in enumerate(p_corr):
            out[format(idx, f"0{self.num_qubits}b")] = float(p)
        return out
