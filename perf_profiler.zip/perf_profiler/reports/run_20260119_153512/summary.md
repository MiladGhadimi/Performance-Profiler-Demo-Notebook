# Performance Profiler — Demo Report

## 1) Error signature (diagnostics)

| backend   |   readout_p01 |   readout_p10 |   depth_decay |   depth_r2 |
|:----------|--------------:|--------------:|--------------:|-----------:|
| backend_A |        0.016  |        0.032  |     0.041328  |   0.962257 |
| backend_B |        0.0565 |        0.0755 |     0.0825598 |   0.91563  |


## 2) Recommended plan

- **Chosen backend:** `backend_A`

- **Transpiler optimization level:** `2`

- **Readout mitigation:** `False`

- Notes: Rule-based demo policy; can be replaced by Bayesian/ML tuner.

## 3) Algorithm suite results (success proxy)

Baseline is the best default run across available backends. Optimized is the recommended run.

| circuit            |   baseline |   optimized |   improve_% |
|:-------------------|-----------:|------------:|------------:|
| gdj_toy_3_balanced |     0.4435 |      0.456  |     2.81849 |
| ghz_6              |     0.411  |      0.43   |     4.62287 |
| qaoa_like_6        |     0.1125 |      0.109  |    -3.11111 |
| random_6           |     0.0545 |      0.0575 |     5.50459 |

