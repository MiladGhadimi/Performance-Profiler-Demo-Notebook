#  Performance Profiler (Demo)

A small, **hardware-agnostic** demo that mimics what an error-management platform might do:

- generate a few *diagnostic* and *algorithm* circuit families,
- run them on multiple backends (here: two **simulated** backends with different noise fingerprints),
- extract an **error signature** (readout bias + depth sensitivity + 2Q sensitivity),
- recommend an execution plan (backend + transpiler level + readout mitigation),
- produce a clean report with plots.

This is intentionally lightweight and designed for interview demos.

## Quick start

1) Create an environment and install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # (Windows: .venv\\Scripts\\activate)
pip install -r requirements.txt
```

2) Run the demo:

```bash
python run.py --shots 2000 --max_qubits 6
```

3) Outputs

A folder is created under `reports/` containing:
- `summary.md` (human-readable report)
- `signature.csv` (per-backend metrics)
- plots (baseline vs optimized, signature overview)

## What this demo shows (talk track)

- **Algorithm-level profiling**: not a full compiler IR, but practical profiling to guide execution.
- **Error signatures** that are easy to compute and compare across backends.
- **Actionable recommendation** that changes transpiler knobs and mitigation switches.

## Notes

- Backends are simulated using `qiskit-aer` with two different noise models.
- Readout mitigation is implemented via confusion-matrix inversion (tensor-product assumption).

