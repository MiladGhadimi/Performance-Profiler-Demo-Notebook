"""Entry point for the Performance Profiler demo."""

from __future__ import annotations

import argparse
import datetime as _dt
from pathlib import Path

import pandas as pd

from profiler.backends import make_demo_backends
from profiler.circuits import (
    make_readout_calibration_circuits,
    make_depth_sweep_circuits,
    make_algorithm_suite,
)
from profiler.metrics import (
    compute_readout_confusion,
    compute_depth_signature,
    compute_suite_metrics,
)
from profiler.mitigation import ReadoutMitigator
from profiler.recommend import recommend_plan
from profiler.reporting import (
    plot_signature_overview,
    plot_baseline_vs_optimized,
    write_markdown_summary,
)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--shots", type=int, default=2000)
    ap.add_argument("--max_qubits", type=int, default=6)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    out_dir = Path(args.out) if args.out else Path("reports") / _dt.datetime.now().strftime("run_%Y%m%d_%H%M%S")
    out_dir.mkdir(parents=True, exist_ok=True)

    backends = make_demo_backends()

    # --- Diagnostics ---
    readout_cals = make_readout_calibration_circuits(n=1)
    depth_sweep = make_depth_sweep_circuits(n=4, depths=[1, 2, 3, 4, 5, 6])

    signature_rows = []

    for b in backends:
        # Readout confusion matrix (1-qubit)
        M = compute_readout_confusion(b, readout_cals, shots=args.shots)

        # Depth signature (4-qubit GHZ fidelity proxy vs depth)
        depth_sig = compute_depth_signature(b, depth_sweep, shots=args.shots)

        signature_rows.append(
            {
                "backend": b.name,
                "readout_p01": float(M[0, 1]),
                "readout_p10": float(M[1, 0]),
                "depth_decay": float(depth_sig["decay_rate"]),
                "depth_r2": float(depth_sig["r2"]),
            }
        )

    sig_df = pd.DataFrame(signature_rows).sort_values("backend")
    sig_df.to_csv(out_dir / "signature.csv", index=False)

    # --- Algorithm suite evaluation ---
    suite = make_algorithm_suite(max_qubits=args.max_qubits)

    # Baseline: per-backend, default settings
    baseline_df = compute_suite_metrics(backends, suite, shots=args.shots, opt_level=1, mitigator=None)

    # Recommend a plan (choose backend + knobs)
    plan = recommend_plan(sig_df)

    # Optimized run
    mitigator = None
    if plan["readout_mitigation"]:
        # build mitigator from chosen backend's confusion matrix
        chosen_backend = next(b for b in backends if b.name == plan["backend"])
        M = compute_readout_confusion(chosen_backend, readout_cals, shots=args.shots)
        mitigator = ReadoutMitigator.from_1q_confusion(M, num_qubits=args.max_qubits)

    optimized_df = compute_suite_metrics(
        [b for b in backends if b.name == plan["backend"]],
        suite,
        shots=args.shots,
        opt_level=int(plan["opt_level"]),
        mitigator=mitigator,
    )

    baseline_df.to_csv(out_dir / "baseline.csv", index=False)
    optimized_df.to_csv(out_dir / "optimized.csv", index=False)

    # Plots + report
    plot_signature_overview(sig_df, out_path=out_dir / "signature_overview.png")
    plot_baseline_vs_optimized(baseline_df, optimized_df, out_path=out_dir / "baseline_vs_optimized.png")

    write_markdown_summary(
        out_path=out_dir / "summary.md",
        signature=sig_df,
        plan=plan,
        baseline=baseline_df,
        optimized=optimized_df,
    )

    print("\nDone.")
    print(f"Report folder: {out_dir.resolve()}")
    print("Key files:")
    print(" - summary.md")
    print(" - signature.csv")
    print(" - signature_overview.png")
    print(" - baseline_vs_optimized.png\n")


if __name__ == "__main__":
    main()
